<center>
		<footer>
		
		<p>VIT LEARNING MANAGMENT SYSTEM 2022</p>
			<!-- <p>Programmed by: John Kevin Lorayna BSIS 4-A</p> -->
		</footer>
</center>

