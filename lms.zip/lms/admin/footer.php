<div class="pull-right">
		<footer>
           <p>Programmed by: Rajat </p>
        <footer>
</div>